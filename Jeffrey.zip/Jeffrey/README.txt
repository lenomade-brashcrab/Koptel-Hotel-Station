
 Events Package Proposal

 Nomad Hospitality Group

 Dear Prospect,

 Re-imagine the art of doing business with inspiring meeting spaces 

 given a Malaysia-centric makeover showcasing the colourful culture, food and heritage.

 "MY Meetings by NOMAD HOSPITALITY GROUP" 

 connects the many facets of authentic Malaysian culture with enriching themed meeting packages.

 Look forward to immersive cultural concepts and cuisine, traditional performances,

 teambuilding and multicultural themed breaks.

 Whatever the size or complexity of a business gathering, the engaging spaces are 

 designed for success. Explore the varied options throughout Malaysia for a corporate event,

 seminar or business meeting with Nomad Hospitality Group unique portfolio

 of properties in Malaysia, ranging from Kuala Lumpur's urban vibrancy to the lush scenery of Langkawi or Sabah.


 To Request Proposal, kindly email jeffrey@brashcrab.com 

 # Why we need APPS

 # Why You Should Geo Target Travelers Based on Intent | Sojern
 # https://www.sojern.com/blog/geo-target-travelers-intent/
 # By leveraging audience intent data, advertisers can improve the user experience ...
 # By continuously testing a variety of { travel intent } and marketing messages, we ...
 # Clicktripz Publisher ID: 705
 # A device comprising instructions that when executed 
 # perform a method for displaying a travel interface comprising:
 # evaluating a set of historical user location data - Geo Target On Device
 # associated with a device of the user to determine a location of a user hub;
 # user hub = check OpenCell framework!!
 # evaluating a set of user signals associated with a user
 # to identify a destination and a future travel date; /* Grab droidsondroid 1979 Payload!! */
 # identifying a predicted travel intent
 # for a user to travel to the potential destination based
 # on a distance from the user hub to the destination exceeding a predetermined threshold;
 # check device Facebook SDK!!
 # generating a travel interface populated with one or more recommendations
 # associated with the destination and the future travel date,
 # a recommendation comprising at least one of an image, weather information, attraction information,
 # event information, an advertisement, a news story, or 
 # travel task completion information associated with the destination; and
 # displaying the travel interface through at least one
 # of an operating system user interface, a mobile app, or a website.
 # SureMDM provides the ability to silently install updates on devices. 
 # Once the guests check out, the devices can be remotely cleaned for any private user data.
 # Tune Hotels url: https://www.42gears.com/hospitality/

 Sample Pseudo:

 
        String status = null;
        if ( geoFenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER )
            status = "Entering ";

        else if ( geoFenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT )
            status = "Exiting ";
        else if (geoFenceTransition==Geofence.GEOFENCE_TRANSITION_DWELL)
            status="dwelling";
        System.out.println("Status Of Geo Fence Transiiton is:::::::::::::::::::::::::::::::::::::::::::::::::::::::::"+status);
        showNotification("GeoFence Status",status);